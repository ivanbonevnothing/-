package com.test.ssdtest

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class R(val b: ByteArray, var p: Int) {
    fun v(): Long {
        var r = 0L
        var sh = 0
        while (p < b.size) {
            val x = b[p++].toInt() and 0xFF
            r = r or ((x and 0x7F).toLong() shl sh)
            if ((x and 0x80) == 0) break
            sh += 7
        }
        return r
    }
}

class MainActivity : Activity() {
    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val btn = Button(this).apply {
            text = "Избери папка с RAR файлове"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 1)
            }
        }
        out = TextView(this).apply {
            setPadding(32, 32, 32, 32)
            setTextIsSelectable(true)
            text = "Избери папката на SSD-то, където са RAR файловете."
        }
        val scroll = ScrollView(this).apply { addView(out) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 96, 0, 0)
            addView(btn)
            addView(scroll)
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        out.text = "Чета заглавията..."
        Thread {
            val res = try { scan(uri) } catch (e: Exception) { "Грешка: ${e.message}" }
            runOnUiThread { out.text = res }
        }.start()
    }

    private fun scan(tree: Uri): String {
        val id = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        val sb = StringBuilder()
        contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val docId = c.getString(0)
                val name = c.getString(1) ?: "?"
                if (!name.endsWith(".rar", true)) continue
                val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                sb.append(name).append('\n').append("   ").append(analyze(docUri)).append("\n\n")
            }
        }
        return sb.toString().ifEmpty { "Няма .rar файлове в тази папка" }
    }

    private fun yn(b: Boolean) = if (b) "да" else "не"

    private fun analyze(uri: Uri): String {
        return try {
            val buf = ByteArray(8192)
            var n = 0
            contentResolver.openInputStream(uri)?.use { s ->
                while (n < buf.size) {
                    val r = s.read(buf, n, buf.size - n)
                    if (r <= 0) break
                    n += r
                }
            }
            if (n < 16) return "не се чете"
            val sig = byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07)
            for (i in sig.indices) if (buf[i] != sig[i]) return "не е RAR (или е друг формат)"
            when (buf[6].toInt()) {
                0 -> rar4(buf, n)
                1 -> rar5(buf, n)
                else -> "непознат RAR"
            }
        } catch (e: Exception) {
            "грешка: ${e.message}"
        }
    }

    private fun u16(b: ByteArray, p: Int) = (b[p].toInt() and 0xFF) or ((b[p + 1].toInt() and 0xFF) shl 8)

    private fun rar4(b: ByteArray, n: Int): String {
        var pos = 7
        var solid = false
        var hdrEnc = false
        var guard = 0
        while (guard++ < 8 && pos + 32 < n) {
            val type = b[pos + 2].toInt() and 0xFF
            val flags = u16(b, pos + 3)
            val size = u16(b, pos + 5)
            if (type == 0x73) {
                solid = (flags and 0x08) != 0
                hdrEnc = (flags and 0x80) != 0
                if (hdrEnc) break
            } else if (type == 0x74) {
                val method = b[pos + 25].toInt() and 0xFF
                val fileEnc = (flags and 0x04) != 0
                return "RAR4 | solid: ${yn(solid)} | криптирани заглавия: не | първи файл: " +
                    (if (method == 0x30) "без компресия" else "с компресия") +
                    " | парола на файла: ${yn(fileEnc)}"
            }
            if (size < 7) break
            pos += size
            if ((flags and 0x8000) != 0 && type != 0x74) {
                pos += (b[pos - size + 7].toInt() and 0xFF) or
                    ((b[pos - size + 8].toInt() and 0xFF) shl 8) or
                    ((b[pos - size + 9].toInt() and 0xFF) shl 16) or
                    ((b[pos - size + 10].toInt() and 0xFF) shl 24)
            }
        }
        return "RAR4 | solid: ${yn(solid)} | криптирани заглавия: ${yn(hdrEnc)}" +
            (if (hdrEnc) " (имената на файловете са скрити зад парола)" else "")
    }

    private fun rar5(b: ByteArray, n: Int): String {
        val r = R(b, 8)
        var solid = false
        var hdrEnc = false
        var guard = 0
        while (guard++ < 6 && r.p + 8 < n) {
            r.p += 4
            val hs = r.v().toInt()
            val start = r.p
            val end = start + hs
            if (hs <= 0 || end > n) break
            val type = r.v().toInt()
            val flags = r.v().toInt()
            var extra = 0
            var data = 0L
            if ((flags and 1) != 0) extra = r.v().toInt()
            if ((flags and 2) != 0) data = r.v()
            when (type) {
                4 -> { hdrEnc = true }
                1 -> {
                    val af = r.v().toInt()
                    solid = (af and 4) != 0
                }
                2 -> {
                    val ffl = r.v().toInt()
                    r.v(); r.v()
                    if ((ffl and 2) != 0) r.p += 4
                    if ((ffl and 4) != 0) r.p += 4
                    val ci = r.v().toInt()
                    val method = (ci shr 7) and 7
                    var fileEnc = false
                    var ep = end - extra
                    var g2 = 0
                    while (ep < end && g2++ < 10) {
                        val er = R(b, ep)
                        val sz = er.v().toInt()
                        val body = er.p
                        val t = er.v().toInt()
                        if (t == 1) fileEnc = true
                        if (sz <= 0) break
                        ep = body + sz
                    }
                    return "RAR5 | solid: ${yn(solid)} | криптирани заглавия: не | първи файл: " +
                        (if (method == 0) "без компресия" else "с компресия") +
                        " | парола на файла: ${yn(fileEnc)}"
                }
            }
            if (hdrEnc) break
            if (data > Int.MAX_VALUE) break
            r.p = end + data.toInt()
        }
        return "RAR5 | solid: ${yn(solid)} | криптирани заглавия: ${yn(hdrEnc)}" +
            (if (hdrEnc) " (имената на файловете са скрити зад парола)" else "")
    }
}
